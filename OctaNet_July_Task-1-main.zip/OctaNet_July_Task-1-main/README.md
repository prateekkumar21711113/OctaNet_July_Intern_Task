# OctaNet_July
The project is organized into the following directories:

Task1: Contains a Landing Page.
